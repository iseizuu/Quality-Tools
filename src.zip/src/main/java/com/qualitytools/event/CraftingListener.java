package com.qualitytools.event;

import com.qualitytools.quality.WeaponQuality;
import com.qualitytools.quality.WeaponQualityHelper;
import net.minecraft.item.ItemStack;

import java.util.Random;

public class CraftingListener {

    public static void applyQuality(ItemStack stack) {

        if (stack.isEmpty()) return;
        if (WeaponQualityHelper.getQuality(stack) != WeaponQuality.FINE) return;

        WeaponQuality quality =
                WeaponQualityHelper.getRandomQuality(new Random());

        WeaponQualityHelper.setQuality(stack, quality);
    }

    public static void register() {
    }
}